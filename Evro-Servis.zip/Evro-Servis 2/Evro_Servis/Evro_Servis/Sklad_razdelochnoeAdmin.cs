﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Evro_Servis
{
    public partial class Sklad_razdelochnoeAdmin : Form
    {
        public Sklad_razdelochnoeAdmin()
        {
            InitializeComponent();
        }
        private void Sotrudniki_Click(object sender, EventArgs e)
        {
            SotrudnikiAdmin fm = new SotrudnikiAdmin();
            fm.Show();
            this.Hide();
        }
        private void Zhivaya_ryba_Click(object sender, EventArgs e)
        {
            Zhivaya_rybaAdmin fm = new Zhivaya_rybaAdmin();
            fm.Show();
            this.Hide();
        }

        private void Ryba_Click(object sender, EventArgs e)
        {
            RybaAdmin fm = new RybaAdmin();
            fm.Show();
            this.Hide();
        }

        private void Vyhod_Click(object sender, EventArgs e)
        {
            AvtorizaciyaFM fm = new AvtorizaciyaFM();
            fm.Show();
            this.Hide();
        }

        private void Sklad_koprilnya_Click(object sender, EventArgs e)
        {
            Sklad_koptilnyaAdmin fm = new Sklad_koptilnyaAdmin();
            fm.Show();
            this.Hide();
        }

        private void Sklad_razdelochnoe_Click(object sender, EventArgs e)
        {
            Sklad_razdelochnoeAdmin fm = new Sklad_razdelochnoeAdmin();
            fm.Show();
            this.Hide();
        }

        private void Sklad_zamorozka_Click(object sender, EventArgs e)
        {
            Sklad_zamorozkaAdmin fm = new Sklad_zamorozkaAdmin();
            fm.Show();
            this.Hide();
        }

        private void Pererabotka_Click(object sender, EventArgs e)
        {
            Pererabotka_KoptilnyaAdmin fm = new Pererabotka_KoptilnyaAdmin();
            fm.Show();
            this.Hide();
        }

        private void Pervaya_Click(object sender, EventArgs e)
        {
            sklad_razdelochnoyeBindingSource.MoveFirst();
        }

        private void Sleduushaya_Click(object sender, EventArgs e)
        {
            sklad_razdelochnoyeBindingSource.MoveNext();
        }

        private void Predydushaya_Click(object sender, EventArgs e)
        {
            sklad_razdelochnoyeBindingSource.MovePrevious();
        }

        private void Poslednyaya_Click(object sender, EventArgs e)
        {
            sklad_razdelochnoyeBindingSource.MoveLast();
        }

        private void Dobavit_Click(object sender, EventArgs e)
        {
            sklad_razdelochnoyeBindingSource.AddNew();
        }

        private void Ydalit_Click(object sender, EventArgs e)
        {
            sklad_razdelochnoyeBindingSource.RemoveCurrent();
        }

        private void Sohranit_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.sklad_razdelochnoyeBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.evro_Servis_BDDataSet);
        }

        private void Nazad_Click(object sender, EventArgs e)
        {
            MenuAdmin fm = new MenuAdmin();
            fm.Show();
            this.Hide();
        }
        private void Filtr_CheckedChanged(object sender, EventArgs e)
        {
            sklad_razdelochnoyeBindingSource.Filter = "Naimenovanie='" + comboBoxFiltr.Text + "'";
        }
        private void SbrositFiltr_Click(object sender, EventArgs e)
        {
            sklad_razdelochnoyeBindingSource.Filter = "";
        }
        private void Sklad_razdelochnoeAdmin_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "evro_Servis_BDDataSet.Sklad_razdelochnoye". При необходимости она может быть перемещена или удалена.
            this.sklad_razdelochnoyeTableAdapter.Fill(this.evro_Servis_BDDataSet.Sklad_razdelochnoye);

        }
    }
}