﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Evro_Servis
{
    public partial class Titulnaya : Form
    {
        public Titulnaya()
        {
            InitializeComponent();
        }
        private void Vyiti_Click(object sender, EventArgs e)
        {
            DialogResult dialog = MessageBox.Show("Вы действительно хотите выйти?", "Завершение программы", MessageBoxButtons.YesNo);
            if (dialog == DialogResult.Yes)
            {
                this.Close();
            }
        }
        private void Avtorizaciya_Click(object sender, EventArgs e)
        {
            AvtorizaciyaFM fm = new AvtorizaciyaFM();
            fm.Show();
            this.Hide();
        }
    }
}
