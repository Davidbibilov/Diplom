﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Evro_Servis
{
    public partial class AvtorizaciyaFM : Form
    {
        static int counter = 0;
        Timer tmr = new Timer();
        public AvtorizaciyaFM()
        {
            InitializeComponent();
        }

        private void Voiti_Click(object sender, EventArgs e)
        {
            counter++;
            SqlConnection sqlcon = new SqlConnection(@"Data Source=DESKTOP-5OGH5AD\SQLEXPRESS;Initial Catalog=Evro_Servis;Integrated Security=True");
            string query = "Select * from [Users] Where Email = '" + Email.Text.Trim() + "' and Password = '" + Password.Text.Trim() + "'";
            SqlDataAdapter sda = new SqlDataAdapter(query, sqlcon);
            DataTable dtbi = new DataTable();
            sda.Fill(dtbi);
            if (dtbi.Rows.Count > 0)
            {
                for (int i = 0; i < dtbi.Rows.Count; i++)
                {
                    if (dtbi.Rows[i]["RoleID"].ToString() == "Administrator" && dtbi.Rows[i]["Active"].ToString() == "1")
                    {
                        MenuAdmin fm = new MenuAdmin();
                        fm.Show();
                        this.Hide();
                        MessageBox.Show("Добро пожаловать");
                    }
                    else if (dtbi.Rows[i]["RoleID"].ToString() == "User" && dtbi.Rows[i]["Active"].ToString() == "1")
                    {
                        MenuUser fm = new MenuUser();
                        fm.Show();
                        this.Hide();
                        MessageBox.Show("Добро пожаловать");
                    }
                    else if (dtbi.Rows[i]["Active"].ToString() == "0")
                    {
                        MessageBox.Show("Лимит входа слишком велик");
                        Email.Enabled = false;
                        Password.Enabled = false;
                        tmr.Start();
                        i++;
                        if (i == 3)
                        {

                        }
                    }
                }
            }
            else MessageBox.Show("Логин или пароль введены неверно");
            {

            }
        }
        private void Timer_Tick_1(Object sender, EventArgs e)
        {
            Email.Enabled = true;
            Password.Enabled = true;
            counter = 0;
            tmr.Stop();
            tmr.Interval = tmr.Interval + 5;
        }

        private void Nazad_Click(object sender, EventArgs e)
        {
            Titulnaya fm = new Titulnaya();
            fm.Show();
            this.Hide();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            MenuAdmin fm = new MenuAdmin();
            fm.Show();
            this.Hide();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            MenuUser fm = new MenuUser();
            fm.Show();
            this.Hide();
        }
    }
}

