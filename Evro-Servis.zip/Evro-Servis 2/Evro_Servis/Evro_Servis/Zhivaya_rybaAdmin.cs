﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Evro_Servis
{
    public partial class Zhivaya_rybaAdmin : Form
    {
        public Zhivaya_rybaAdmin()
        {
            InitializeComponent();
        }
        private void SotrudnikiAdmin_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "evro_Servis_BDDataSet.Zhivaya_ryba". При необходимости она может быть перемещена или удалена.
            this.zhivaya_rybaTableAdapter.Fill(this.evro_Servis_BDDataSet.Zhivaya_ryba);

        }
        private void Sotrudniki_Click(object sender, EventArgs e)
        {
            SotrudnikiAdmin fm = new SotrudnikiAdmin();
            fm.Show();
            this.Hide();
        }

        private void Otchet_proizvodstva_Click(object sender, EventArgs e)
        {
            OtchetProizvodstvaAdmin fm = new OtchetProizvodstvaAdmin();
            fm.Show();
            this.Hide();
        }

        private void Sklady_Click(object sender, EventArgs e)
        {
            Sklad_koptilnyaAdmin fm = new Sklad_koptilnyaAdmin();
            fm.Show();
            this.Hide();
        }

        private void Ryba_Click(object sender, EventArgs e)
        {
            RybaAdmin fm = new RybaAdmin();
            fm.Show();
            this.Hide();
        }

        private void Zhivaya_ryba_Click(object sender, EventArgs e)
        {
            Zhivaya_rybaAdmin fm = new Zhivaya_rybaAdmin();
            fm.Show();
            this.Hide();
        }

        private void Pererabotka_Click(object sender, EventArgs e)
        {
            Pererabotka_KoptilnyaAdmin fm = new Pererabotka_KoptilnyaAdmin();
            fm.Show();
            this.Hide();
        }

        private void Vyhod_Click(object sender, EventArgs e)
        {
            AvtorizaciyaFM fm = new AvtorizaciyaFM();
            fm.Show();
            this.Hide();
        }

        private void Pervaya_Click(object sender, EventArgs e)
        {
            zhivaya_rybaBindingSource.MoveFirst();
        }

        private void Sleduushaya_Click(object sender, EventArgs e)
        {
            zhivaya_rybaBindingSource.MoveNext();
        }

        private void Predydushaya_Click(object sender, EventArgs e)
        {
            zhivaya_rybaBindingSource.MovePrevious();
        }

        private void Poslednyaya_Click(object sender, EventArgs e)
        {
            zhivaya_rybaBindingSource.MoveLast();
        }

        private void Dobavit_Click(object sender, EventArgs e)
        {
            zhivaya_rybaBindingSource.AddNew();
        }

        private void Ydalit_Click(object sender, EventArgs e)
        {
            zhivaya_rybaBindingSource.RemoveCurrent();
        }

        private void Sohranit_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.zhivaya_rybaBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.evro_Servis_BDDataSet);
        }

        private void Nazad_Click(object sender, EventArgs e)
        {
            MenuAdmin fm = new MenuAdmin();
            fm.Show();
            this.Hide();
        }
        private void Filtr_CheckedChanged(object sender, EventArgs e)
        {
            zhivaya_rybaBindingSource.Filter = "Naimenovanie='" + comboBoxFiltr.Text + "'";
        }
        private void SbrositFiltr_Click(object sender, EventArgs e)
        {
            zhivaya_rybaBindingSource.Filter = "";
        }
    }
}