﻿
namespace Evro_Servis
{
    partial class MenuAdmin
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MenuAdmin));
            this.TopShapka = new System.Windows.Forms.Label();
            this.Vyhod = new System.Windows.Forms.Button();
            this.Vyiti = new System.Windows.Forms.Button();
            this.Zagolovok = new System.Windows.Forms.Label();
            this.Logo = new System.Windows.Forms.PictureBox();
            this.Pererabotka_razdelochnoe = new System.Windows.Forms.Button();
            this.Pererabotka_zamorozka = new System.Windows.Forms.Button();
            this.Zhivaya_ryba = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.Ryba = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.Pererabotka_koptilnya = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.Sotrudniki = new System.Windows.Forms.Button();
            this.Otchet_proizvodstvo = new System.Windows.Forms.Button();
            this.Sklad_razdelochnoe = new System.Windows.Forms.Button();
            this.Sklad_zamorozka = new System.Windows.Forms.Button();
            this.Sklad_koptilnya = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.Logo)).BeginInit();
            this.SuspendLayout();
            // 
            // TopShapka
            // 
            this.TopShapka.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.TopShapka.Location = new System.Drawing.Point(-5, -1);
            this.TopShapka.Name = "TopShapka";
            this.TopShapka.Size = new System.Drawing.Size(1592, 157);
            this.TopShapka.TabIndex = 70;
            // 
            // Vyhod
            // 
            this.Vyhod.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Vyhod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Vyhod.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Vyhod.ForeColor = System.Drawing.Color.Yellow;
            this.Vyhod.Location = new System.Drawing.Point(1232, 12);
            this.Vyhod.Name = "Vyhod";
            this.Vyhod.Size = new System.Drawing.Size(294, 62);
            this.Vyhod.TabIndex = 81;
            this.Vyhod.Text = "Выход";
            this.Vyhod.UseVisualStyleBackColor = false;
            this.Vyhod.Click += new System.EventHandler(this.Vyhod_Click);
            // 
            // Vyiti
            // 
            this.Vyiti.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Vyiti.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Vyiti.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Vyiti.ForeColor = System.Drawing.Color.Yellow;
            this.Vyiti.Location = new System.Drawing.Point(1334, 12);
            this.Vyiti.Name = "Vyiti";
            this.Vyiti.Size = new System.Drawing.Size(192, 62);
            this.Vyiti.TabIndex = 80;
            this.Vyiti.Text = "Выйти";
            this.Vyiti.UseVisualStyleBackColor = false;
            // 
            // Zagolovok
            // 
            this.Zagolovok.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Zagolovok.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Zagolovok.ForeColor = System.Drawing.Color.White;
            this.Zagolovok.Location = new System.Drawing.Point(12, 80);
            this.Zagolovok.Name = "Zagolovok";
            this.Zagolovok.Size = new System.Drawing.Size(326, 62);
            this.Zagolovok.TabIndex = 74;
            this.Zagolovok.Text = "Меню";
            this.Zagolovok.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Logo
            // 
            this.Logo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Logo.Image = global::Evro_Servis.Properties.Resources.LogoFM;
            this.Logo.Location = new System.Drawing.Point(12, 12);
            this.Logo.Name = "Logo";
            this.Logo.Size = new System.Drawing.Size(326, 62);
            this.Logo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Logo.TabIndex = 73;
            this.Logo.TabStop = false;
            // 
            // Pererabotka_razdelochnoe
            // 
            this.Pererabotka_razdelochnoe.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Pererabotka_razdelochnoe.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Pererabotka_razdelochnoe.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Pererabotka_razdelochnoe.ForeColor = System.Drawing.Color.White;
            this.Pererabotka_razdelochnoe.Location = new System.Drawing.Point(1072, 546);
            this.Pererabotka_razdelochnoe.Name = "Pererabotka_razdelochnoe";
            this.Pererabotka_razdelochnoe.Size = new System.Drawing.Size(433, 83);
            this.Pererabotka_razdelochnoe.TabIndex = 102;
            this.Pererabotka_razdelochnoe.Text = "Переработка разделочное";
            this.Pererabotka_razdelochnoe.UseVisualStyleBackColor = false;
            this.Pererabotka_razdelochnoe.Click += new System.EventHandler(this.Pererabotka_razdelochnoe_Click);
            // 
            // Pererabotka_zamorozka
            // 
            this.Pererabotka_zamorozka.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Pererabotka_zamorozka.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Pererabotka_zamorozka.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Pererabotka_zamorozka.ForeColor = System.Drawing.Color.White;
            this.Pererabotka_zamorozka.Location = new System.Drawing.Point(1071, 446);
            this.Pererabotka_zamorozka.Name = "Pererabotka_zamorozka";
            this.Pererabotka_zamorozka.Size = new System.Drawing.Size(433, 83);
            this.Pererabotka_zamorozka.TabIndex = 101;
            this.Pererabotka_zamorozka.Text = "Переработка заморозка";
            this.Pererabotka_zamorozka.UseVisualStyleBackColor = false;
            this.Pererabotka_zamorozka.Click += new System.EventHandler(this.Pererabotka_zamorozka_Click);
            // 
            // Zhivaya_ryba
            // 
            this.Zhivaya_ryba.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Zhivaya_ryba.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Zhivaya_ryba.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Zhivaya_ryba.ForeColor = System.Drawing.Color.White;
            this.Zhivaya_ryba.Location = new System.Drawing.Point(75, 494);
            this.Zhivaya_ryba.Name = "Zhivaya_ryba";
            this.Zhivaya_ryba.Size = new System.Drawing.Size(433, 83);
            this.Zhivaya_ryba.TabIndex = 100;
            this.Zhivaya_ryba.Text = "Живая рыба";
            this.Zhivaya_ryba.UseVisualStyleBackColor = false;
            this.Zhivaya_ryba.Click += new System.EventHandler(this.Zhivaya_ryba_Click);
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(75, 229);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(433, 62);
            this.label3.TabIndex = 97;
            this.label3.Text = "Заказы";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Ryba
            // 
            this.Ryba.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Ryba.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Ryba.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Ryba.ForeColor = System.Drawing.Color.White;
            this.Ryba.Location = new System.Drawing.Point(75, 394);
            this.Ryba.Name = "Ryba";
            this.Ryba.Size = new System.Drawing.Size(433, 83);
            this.Ryba.TabIndex = 96;
            this.Ryba.Text = "Рыба";
            this.Ryba.UseVisualStyleBackColor = false;
            this.Ryba.Click += new System.EventHandler(this.Ryba_Click);
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(1072, 281);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(433, 62);
            this.label1.TabIndex = 93;
            this.label1.Text = "Переработка";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Pererabotka_koptilnya
            // 
            this.Pererabotka_koptilnya.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Pererabotka_koptilnya.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Pererabotka_koptilnya.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Pererabotka_koptilnya.ForeColor = System.Drawing.Color.White;
            this.Pererabotka_koptilnya.Location = new System.Drawing.Point(1072, 346);
            this.Pererabotka_koptilnya.Name = "Pererabotka_koptilnya";
            this.Pererabotka_koptilnya.Size = new System.Drawing.Size(433, 83);
            this.Pererabotka_koptilnya.TabIndex = 92;
            this.Pererabotka_koptilnya.Text = "Переработка коптильня";
            this.Pererabotka_koptilnya.UseVisualStyleBackColor = false;
            this.Pererabotka_koptilnya.Click += new System.EventHandler(this.Pererabotka_koptilnya_Click);
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(640, 221);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(296, 122);
            this.label2.TabIndex = 94;
            this.label2.Text = "Продукция на складках";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Sotrudniki
            // 
            this.Sotrudniki.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Sotrudniki.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Sotrudniki.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Sotrudniki.ForeColor = System.Drawing.Color.White;
            this.Sotrudniki.Location = new System.Drawing.Point(75, 294);
            this.Sotrudniki.Name = "Sotrudniki";
            this.Sotrudniki.Size = new System.Drawing.Size(433, 83);
            this.Sotrudniki.TabIndex = 95;
            this.Sotrudniki.Text = "Сотрудники";
            this.Sotrudniki.UseVisualStyleBackColor = false;
            this.Sotrudniki.Click += new System.EventHandler(this.Sotrudniki_Click);
            // 
            // Otchet_proizvodstvo
            // 
            this.Otchet_proizvodstvo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Otchet_proizvodstvo.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Otchet_proizvodstvo.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Otchet_proizvodstvo.ForeColor = System.Drawing.Color.White;
            this.Otchet_proizvodstvo.Location = new System.Drawing.Point(75, 593);
            this.Otchet_proizvodstvo.Name = "Otchet_proizvodstvo";
            this.Otchet_proizvodstvo.Size = new System.Drawing.Size(433, 83);
            this.Otchet_proizvodstvo.TabIndex = 99;
            this.Otchet_proizvodstvo.Text = "Отчет по производству";
            this.Otchet_proizvodstvo.UseVisualStyleBackColor = false;
            this.Otchet_proizvodstvo.Click += new System.EventHandler(this.Otchet_proizvodstvo_Click);
            // 
            // Sklad_razdelochnoe
            // 
            this.Sklad_razdelochnoe.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Sklad_razdelochnoe.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Sklad_razdelochnoe.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Sklad_razdelochnoe.ForeColor = System.Drawing.Color.White;
            this.Sklad_razdelochnoe.Location = new System.Drawing.Point(576, 546);
            this.Sklad_razdelochnoe.Name = "Sklad_razdelochnoe";
            this.Sklad_razdelochnoe.Size = new System.Drawing.Size(433, 83);
            this.Sklad_razdelochnoe.TabIndex = 105;
            this.Sklad_razdelochnoe.Text = "Склад разделочное";
            this.Sklad_razdelochnoe.UseVisualStyleBackColor = false;
            this.Sklad_razdelochnoe.Click += new System.EventHandler(this.Sklad_razdelochnoe_Click);
            // 
            // Sklad_zamorozka
            // 
            this.Sklad_zamorozka.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Sklad_zamorozka.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Sklad_zamorozka.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Sklad_zamorozka.ForeColor = System.Drawing.Color.White;
            this.Sklad_zamorozka.Location = new System.Drawing.Point(576, 446);
            this.Sklad_zamorozka.Name = "Sklad_zamorozka";
            this.Sklad_zamorozka.Size = new System.Drawing.Size(433, 83);
            this.Sklad_zamorozka.TabIndex = 104;
            this.Sklad_zamorozka.Text = "Склад заморозка";
            this.Sklad_zamorozka.UseVisualStyleBackColor = false;
            this.Sklad_zamorozka.Click += new System.EventHandler(this.Sklad_zamorozka_Click);
            // 
            // Sklad_koptilnya
            // 
            this.Sklad_koptilnya.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Sklad_koptilnya.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Sklad_koptilnya.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Sklad_koptilnya.ForeColor = System.Drawing.Color.White;
            this.Sklad_koptilnya.Location = new System.Drawing.Point(576, 346);
            this.Sklad_koptilnya.Name = "Sklad_koptilnya";
            this.Sklad_koptilnya.Size = new System.Drawing.Size(433, 83);
            this.Sklad_koptilnya.TabIndex = 103;
            this.Sklad_koptilnya.Text = "Склад коптильня";
            this.Sklad_koptilnya.UseVisualStyleBackColor = false;
            this.Sklad_koptilnya.Click += new System.EventHandler(this.Sklad_koptilnya_Click);
            // 
            // MenuAdmin
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(1582, 753);
            this.Controls.Add(this.Sklad_razdelochnoe);
            this.Controls.Add(this.Sklad_zamorozka);
            this.Controls.Add(this.Sklad_koptilnya);
            this.Controls.Add(this.Pererabotka_razdelochnoe);
            this.Controls.Add(this.Pererabotka_zamorozka);
            this.Controls.Add(this.Zhivaya_ryba);
            this.Controls.Add(this.Otchet_proizvodstvo);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.Ryba);
            this.Controls.Add(this.Sotrudniki);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Pererabotka_koptilnya);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Vyhod);
            this.Controls.Add(this.Vyiti);
            this.Controls.Add(this.Zagolovok);
            this.Controls.Add(this.Logo);
            this.Controls.Add(this.TopShapka);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MenuAdmin";
            this.Text = "Евро-Сервис - Меню";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)(this.Logo)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label TopShapka;
        private System.Windows.Forms.Button Vyhod;
        private System.Windows.Forms.Button Vyiti;
        private System.Windows.Forms.Label Zagolovok;
        private System.Windows.Forms.PictureBox Logo;
        private System.Windows.Forms.Button Pererabotka_razdelochnoe;
        private System.Windows.Forms.Button Pererabotka_zamorozka;
        private System.Windows.Forms.Button Zhivaya_ryba;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button Ryba;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Pererabotka_koptilnya;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button Sotrudniki;
        private System.Windows.Forms.Button Otchet_proizvodstvo;
        private System.Windows.Forms.Button Sklad_razdelochnoe;
        private System.Windows.Forms.Button Sklad_zamorozka;
        private System.Windows.Forms.Button Sklad_koptilnya;
    }
}

