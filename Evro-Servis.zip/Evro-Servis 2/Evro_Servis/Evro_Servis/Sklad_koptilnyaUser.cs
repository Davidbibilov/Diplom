﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Evro_Servis
{
    public partial class Sklad_koptilnyaUser : Form
    {
        public Sklad_koptilnyaUser()
        {
            InitializeComponent();
        }
        private void Sotrudniki_Click(object sender, EventArgs e)
        {
            SotrudnikiUser fm = new SotrudnikiUser();
            fm.Show();
            this.Hide();
        }

        private void Ryba_Click(object sender, EventArgs e)
        {
            RybaUser fm = new RybaUser();
            fm.Show();
            this.Hide();
        }

        private void Vyhod_Click(object sender, EventArgs e)
        {
            AvtorizaciyaFM fm = new AvtorizaciyaFM();
            fm.Show();
            this.Hide();
        }

        private void Sklad_koprilnya_Click(object sender, EventArgs e)
        {
            Sklad_koptilnyaUser fm = new Sklad_koptilnyaUser();
            fm.Show();
            this.Hide();
        }

        private void Sklad_razdelochnoe_Click(object sender, EventArgs e)
        {
            Sklad_razdelochnoeUser fm = new Sklad_razdelochnoeUser();
            fm.Show();
            this.Hide();
        }

        private void Sklad_zamorozka_Click(object sender, EventArgs e)
        {
            Sklad_zamorozkaUser fm = new Sklad_zamorozkaUser();
            fm.Show();
            this.Hide();
        }

        private void Pererabotka_Click(object sender, EventArgs e)
        {
            Pererabotka_KoptilnyaUser fm = new Pererabotka_KoptilnyaUser();
            fm.Show();
            this.Hide();
        }

        private void Pervaya_Click(object sender, EventArgs e)
        {
            sklad_koptilnyaBindingSource.MoveFirst();
        }

        private void Sleduushaya_Click(object sender, EventArgs e)
        {
            sklad_koptilnyaBindingSource.MoveNext();
        }

        private void Predydushaya_Click(object sender, EventArgs e)
        {
            sklad_koptilnyaBindingSource.MovePrevious();
        }

        private void Poslednyaya_Click(object sender, EventArgs e)
        {
            sklad_koptilnyaBindingSource.MoveLast();
        }
        private void Nazad_Click(object sender, EventArgs e)
        {
            MenuUser fm = new MenuUser();
            fm.Show();
            this.Hide();
        }
        private void Filtr_CheckedChanged(object sender, EventArgs e)
        {
            sklad_koptilnyaBindingSource.Filter = "Naimenovanie='" + comboBoxFiltr.Text + "'";
        }
        private void SbrositFiltr_Click(object sender, EventArgs e)
        {
            sklad_koptilnyaBindingSource.Filter = "";
        }
        private void Sklad_koptilnyaAdmin_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "evro_Servis_BDDataSet.Sklad_koptilnya". При необходимости она может быть перемещена или удалена.
            this.sklad_koptilnyaTableAdapter.Fill(this.evro_Servis_BDDataSet.Sklad_koptilnya);

        }
    }
}