﻿
namespace Evro_Servis
{
    partial class Pererabotka_KoptilnyaAdmin
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Pererabotka_KoptilnyaAdmin));
            this.TopShapka = new System.Windows.Forms.Label();
            this.Vyhod = new System.Windows.Forms.Button();
            this.Zagolovok = new System.Windows.Forms.Label();
            this.Logo = new System.Windows.Forms.PictureBox();
            this.Zhivaya_ryba = new System.Windows.Forms.Button();
            this.Ryba = new System.Windows.Forms.Button();
            this.Sotrudniki = new System.Windows.Forms.Button();
            this.comboBoxFiltr = new System.Windows.Forms.ComboBox();
            this.pererabotka_koptilnyaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.evro_Servis_BDDataSet = new Evro_Servis.Evro_Servis_BDDataSet();
            this.SbrositFiltr = new System.Windows.Forms.Button();
            this.Filtr = new System.Windows.Forms.CheckBox();
            this.Sohranit = new System.Windows.Forms.Button();
            this.Dobavit = new System.Windows.Forms.Button();
            this.Ydalit = new System.Windows.Forms.Button();
            this.Poslednyaya = new System.Windows.Forms.Button();
            this.Sleduushaya = new System.Windows.Forms.Button();
            this.Predydushaya = new System.Windows.Forms.Button();
            this.Pervaya = new System.Windows.Forms.Button();
            this.Nazad = new System.Windows.Forms.Button();
            this.Sklady = new System.Windows.Forms.Button();
            this.Pererabotka_koprilnya = new System.Windows.Forms.Button();
            this.Pererabotka_razdelochnoe = new System.Windows.Forms.Button();
            this.Pererabotka_zamorozka = new System.Windows.Forms.Button();
            this.pererabotka_koptilnyaTableAdapter = new Evro_Servis.Evro_Servis_BDDataSetTableAdapters.Pererabotka_koptilnyaTableAdapter();
            this.tableAdapterManager = new Evro_Servis.Evro_Servis_BDDataSetTableAdapters.TableAdapterManager();
            this.pererabotka_koptilnyaDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.Logo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pererabotka_koptilnyaBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.evro_Servis_BDDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pererabotka_koptilnyaDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // TopShapka
            // 
            this.TopShapka.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.TopShapka.Location = new System.Drawing.Point(-5, -1);
            this.TopShapka.Name = "TopShapka";
            this.TopShapka.Size = new System.Drawing.Size(1592, 157);
            this.TopShapka.TabIndex = 70;
            // 
            // Vyhod
            // 
            this.Vyhod.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Vyhod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Vyhod.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Vyhod.ForeColor = System.Drawing.Color.Yellow;
            this.Vyhod.Location = new System.Drawing.Point(1232, 12);
            this.Vyhod.Name = "Vyhod";
            this.Vyhod.Size = new System.Drawing.Size(294, 62);
            this.Vyhod.TabIndex = 81;
            this.Vyhod.Text = "Выход";
            this.Vyhod.UseVisualStyleBackColor = false;
            this.Vyhod.Click += new System.EventHandler(this.Vyhod_Click);
            // 
            // Zagolovok
            // 
            this.Zagolovok.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Zagolovok.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Zagolovok.ForeColor = System.Drawing.Color.White;
            this.Zagolovok.Location = new System.Drawing.Point(12, 80);
            this.Zagolovok.Name = "Zagolovok";
            this.Zagolovok.Size = new System.Drawing.Size(326, 62);
            this.Zagolovok.TabIndex = 74;
            this.Zagolovok.Text = "Коптильня";
            this.Zagolovok.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Logo
            // 
            this.Logo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Logo.Image = global::Evro_Servis.Properties.Resources.LogoFM;
            this.Logo.Location = new System.Drawing.Point(12, 12);
            this.Logo.Name = "Logo";
            this.Logo.Size = new System.Drawing.Size(326, 62);
            this.Logo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Logo.TabIndex = 73;
            this.Logo.TabStop = false;
            // 
            // Zhivaya_ryba
            // 
            this.Zhivaya_ryba.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Zhivaya_ryba.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Zhivaya_ryba.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Zhivaya_ryba.ForeColor = System.Drawing.Color.White;
            this.Zhivaya_ryba.Location = new System.Drawing.Point(797, 12);
            this.Zhivaya_ryba.Name = "Zhivaya_ryba";
            this.Zhivaya_ryba.Size = new System.Drawing.Size(235, 62);
            this.Zhivaya_ryba.TabIndex = 103;
            this.Zhivaya_ryba.Text = "Живая рыба";
            this.Zhivaya_ryba.UseVisualStyleBackColor = false;
            this.Zhivaya_ryba.Click += new System.EventHandler(this.Zhivaya_ryba_Click);
            // 
            // Ryba
            // 
            this.Ryba.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Ryba.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Ryba.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Ryba.ForeColor = System.Drawing.Color.White;
            this.Ryba.Location = new System.Drawing.Point(585, 12);
            this.Ryba.Name = "Ryba";
            this.Ryba.Size = new System.Drawing.Size(206, 62);
            this.Ryba.TabIndex = 102;
            this.Ryba.Text = "Рыба";
            this.Ryba.UseVisualStyleBackColor = false;
            this.Ryba.Click += new System.EventHandler(this.Ryba_Click);
            // 
            // Sotrudniki
            // 
            this.Sotrudniki.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Sotrudniki.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Sotrudniki.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Sotrudniki.ForeColor = System.Drawing.Color.White;
            this.Sotrudniki.Location = new System.Drawing.Point(344, 12);
            this.Sotrudniki.Name = "Sotrudniki";
            this.Sotrudniki.Size = new System.Drawing.Size(235, 62);
            this.Sotrudniki.TabIndex = 101;
            this.Sotrudniki.Text = "Сотрудники";
            this.Sotrudniki.UseVisualStyleBackColor = false;
            this.Sotrudniki.Click += new System.EventHandler(this.Sotrudniki_Click);
            // 
            // comboBoxFiltr
            // 
            this.comboBoxFiltr.DataSource = this.pererabotka_koptilnyaBindingSource;
            this.comboBoxFiltr.DisplayMember = "Naimenovanie";
            this.comboBoxFiltr.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBoxFiltr.FormattingEnabled = true;
            this.comboBoxFiltr.Location = new System.Drawing.Point(901, 188);
            this.comboBoxFiltr.Name = "comboBoxFiltr";
            this.comboBoxFiltr.Size = new System.Drawing.Size(401, 39);
            this.comboBoxFiltr.TabIndex = 129;
            // 
            // pererabotka_koptilnyaBindingSource
            // 
            this.pererabotka_koptilnyaBindingSource.DataMember = "Pererabotka_koptilnya";
            this.pererabotka_koptilnyaBindingSource.DataSource = this.evro_Servis_BDDataSet;
            // 
            // evro_Servis_BDDataSet
            // 
            this.evro_Servis_BDDataSet.DataSetName = "Evro_Servis_BDDataSet";
            this.evro_Servis_BDDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // SbrositFiltr
            // 
            this.SbrositFiltr.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.SbrositFiltr.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.SbrositFiltr.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.SbrositFiltr.ForeColor = System.Drawing.Color.White;
            this.SbrositFiltr.Location = new System.Drawing.Point(1307, 244);
            this.SbrositFiltr.Name = "SbrositFiltr";
            this.SbrositFiltr.Size = new System.Drawing.Size(219, 62);
            this.SbrositFiltr.TabIndex = 128;
            this.SbrositFiltr.Text = "Сбросить";
            this.SbrositFiltr.UseVisualStyleBackColor = false;
            this.SbrositFiltr.Click += new System.EventHandler(this.SbrositFiltr_Click);
            // 
            // Filtr
            // 
            this.Filtr.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Filtr.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Filtr.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Filtr.ForeColor = System.Drawing.Color.White;
            this.Filtr.Location = new System.Drawing.Point(1308, 177);
            this.Filtr.Name = "Filtr";
            this.Filtr.Size = new System.Drawing.Size(218, 62);
            this.Filtr.TabIndex = 127;
            this.Filtr.Text = "Фильтровать";
            this.Filtr.UseVisualStyleBackColor = false;
            this.Filtr.CheckedChanged += new System.EventHandler(this.Filtr_CheckedChanged);
            // 
            // Sohranit
            // 
            this.Sohranit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Sohranit.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Sohranit.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Sohranit.ForeColor = System.Drawing.Color.White;
            this.Sohranit.Location = new System.Drawing.Point(216, 175);
            this.Sohranit.Name = "Sohranit";
            this.Sohranit.Size = new System.Drawing.Size(192, 62);
            this.Sohranit.TabIndex = 126;
            this.Sohranit.Text = "Сохранить";
            this.Sohranit.UseVisualStyleBackColor = false;
            this.Sohranit.Click += new System.EventHandler(this.Sohranit_Click);
            // 
            // Dobavit
            // 
            this.Dobavit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Dobavit.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Dobavit.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Dobavit.ForeColor = System.Drawing.Color.White;
            this.Dobavit.Location = new System.Drawing.Point(18, 285);
            this.Dobavit.Name = "Dobavit";
            this.Dobavit.Size = new System.Drawing.Size(192, 62);
            this.Dobavit.TabIndex = 125;
            this.Dobavit.Text = "Добавить";
            this.Dobavit.UseVisualStyleBackColor = false;
            this.Dobavit.Click += new System.EventHandler(this.Dobavit_Click);
            // 
            // Ydalit
            // 
            this.Ydalit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Ydalit.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Ydalit.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Ydalit.ForeColor = System.Drawing.Color.Yellow;
            this.Ydalit.Location = new System.Drawing.Point(18, 353);
            this.Ydalit.Name = "Ydalit";
            this.Ydalit.Size = new System.Drawing.Size(192, 62);
            this.Ydalit.TabIndex = 124;
            this.Ydalit.Text = "Удалить";
            this.Ydalit.UseVisualStyleBackColor = false;
            this.Ydalit.Click += new System.EventHandler(this.Ydalit_Click);
            // 
            // Poslednyaya
            // 
            this.Poslednyaya.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Poslednyaya.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Poslednyaya.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Poslednyaya.ForeColor = System.Drawing.Color.White;
            this.Poslednyaya.Location = new System.Drawing.Point(968, 675);
            this.Poslednyaya.Name = "Poslednyaya";
            this.Poslednyaya.Size = new System.Drawing.Size(192, 62);
            this.Poslednyaya.TabIndex = 123;
            this.Poslednyaya.Text = "Последняя";
            this.Poslednyaya.UseVisualStyleBackColor = false;
            this.Poslednyaya.Click += new System.EventHandler(this.Poslednyaya_Click);
            // 
            // Sleduushaya
            // 
            this.Sleduushaya.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Sleduushaya.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Sleduushaya.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Sleduushaya.ForeColor = System.Drawing.Color.White;
            this.Sleduushaya.Location = new System.Drawing.Point(770, 636);
            this.Sleduushaya.Name = "Sleduushaya";
            this.Sleduushaya.Size = new System.Drawing.Size(192, 62);
            this.Sleduushaya.TabIndex = 122;
            this.Sleduushaya.Text = "Следующая";
            this.Sleduushaya.UseVisualStyleBackColor = false;
            this.Sleduushaya.Click += new System.EventHandler(this.Sleduushaya_Click);
            // 
            // Predydushaya
            // 
            this.Predydushaya.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Predydushaya.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Predydushaya.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Predydushaya.ForeColor = System.Drawing.Color.White;
            this.Predydushaya.Location = new System.Drawing.Point(572, 636);
            this.Predydushaya.Name = "Predydushaya";
            this.Predydushaya.Size = new System.Drawing.Size(192, 62);
            this.Predydushaya.TabIndex = 121;
            this.Predydushaya.Text = "Предыдущая";
            this.Predydushaya.UseVisualStyleBackColor = false;
            this.Predydushaya.Click += new System.EventHandler(this.Predydushaya_Click);
            // 
            // Pervaya
            // 
            this.Pervaya.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Pervaya.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Pervaya.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Pervaya.ForeColor = System.Drawing.Color.White;
            this.Pervaya.Location = new System.Drawing.Point(374, 675);
            this.Pervaya.Name = "Pervaya";
            this.Pervaya.Size = new System.Drawing.Size(192, 62);
            this.Pervaya.TabIndex = 120;
            this.Pervaya.Text = "Первая";
            this.Pervaya.UseVisualStyleBackColor = false;
            this.Pervaya.Click += new System.EventHandler(this.Pervaya_Click);
            // 
            // Nazad
            // 
            this.Nazad.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Nazad.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Nazad.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Nazad.ForeColor = System.Drawing.Color.Yellow;
            this.Nazad.Location = new System.Drawing.Point(18, 175);
            this.Nazad.Name = "Nazad";
            this.Nazad.Size = new System.Drawing.Size(192, 62);
            this.Nazad.TabIndex = 119;
            this.Nazad.Text = "Назад";
            this.Nazad.UseVisualStyleBackColor = false;
            this.Nazad.Click += new System.EventHandler(this.Nazad_Click);
            // 
            // Sklady
            // 
            this.Sklady.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Sklady.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Sklady.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Sklady.ForeColor = System.Drawing.Color.White;
            this.Sklady.Location = new System.Drawing.Point(1038, 12);
            this.Sklady.Name = "Sklady";
            this.Sklady.Size = new System.Drawing.Size(188, 62);
            this.Sklady.TabIndex = 133;
            this.Sklady.Text = "Склады";
            this.Sklady.UseVisualStyleBackColor = false;
            this.Sklady.Click += new System.EventHandler(this.Sklady_Click);
            // 
            // Pererabotka_koprilnya
            // 
            this.Pererabotka_koprilnya.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Pererabotka_koprilnya.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Pererabotka_koprilnya.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Pererabotka_koprilnya.ForeColor = System.Drawing.Color.White;
            this.Pererabotka_koprilnya.Location = new System.Drawing.Point(344, 80);
            this.Pererabotka_koprilnya.Name = "Pererabotka_koprilnya";
            this.Pererabotka_koprilnya.Size = new System.Drawing.Size(390, 62);
            this.Pererabotka_koprilnya.TabIndex = 132;
            this.Pererabotka_koprilnya.Text = "Переработка коптильня";
            this.Pererabotka_koprilnya.UseVisualStyleBackColor = false;
            this.Pererabotka_koprilnya.Click += new System.EventHandler(this.Pererabotka_koprilnya_Click);
            // 
            // Pererabotka_razdelochnoe
            // 
            this.Pererabotka_razdelochnoe.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Pererabotka_razdelochnoe.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Pererabotka_razdelochnoe.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Pererabotka_razdelochnoe.ForeColor = System.Drawing.Color.White;
            this.Pererabotka_razdelochnoe.Location = new System.Drawing.Point(1136, 80);
            this.Pererabotka_razdelochnoe.Name = "Pererabotka_razdelochnoe";
            this.Pererabotka_razdelochnoe.Size = new System.Drawing.Size(390, 62);
            this.Pererabotka_razdelochnoe.TabIndex = 131;
            this.Pererabotka_razdelochnoe.Text = "Переработка разделочное";
            this.Pererabotka_razdelochnoe.UseVisualStyleBackColor = false;
            this.Pererabotka_razdelochnoe.Click += new System.EventHandler(this.Pererabotka_razdelochnoe_Click);
            // 
            // Pererabotka_zamorozka
            // 
            this.Pererabotka_zamorozka.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Pererabotka_zamorozka.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Pererabotka_zamorozka.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Pererabotka_zamorozka.ForeColor = System.Drawing.Color.White;
            this.Pererabotka_zamorozka.Location = new System.Drawing.Point(740, 80);
            this.Pererabotka_zamorozka.Name = "Pererabotka_zamorozka";
            this.Pererabotka_zamorozka.Size = new System.Drawing.Size(390, 62);
            this.Pererabotka_zamorozka.TabIndex = 130;
            this.Pererabotka_zamorozka.Text = "Переработка заморозка";
            this.Pererabotka_zamorozka.UseVisualStyleBackColor = false;
            this.Pererabotka_zamorozka.Click += new System.EventHandler(this.Pererabotka_zamorozka_Click);
            // 
            // pererabotka_koptilnyaTableAdapter
            // 
            this.pererabotka_koptilnyaTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.Otchety_proizvodstvoTableAdapter = null;
            this.tableAdapterManager.Pererabotka_koptilnyaTableAdapter = this.pererabotka_koptilnyaTableAdapter;
            this.tableAdapterManager.Pererabotka_razdelochnoyeTableAdapter = null;
            this.tableAdapterManager.Pererabotka_zamorozkaTableAdapter = null;
            this.tableAdapterManager.Proizvodstvo_vyrashivaniyeTableAdapter = null;
            this.tableAdapterManager.RybaTableAdapter = null;
            this.tableAdapterManager.Sklad_koptilnyaTableAdapter = null;
            this.tableAdapterManager.Sklad_razdelochnoyeTableAdapter = null;
            this.tableAdapterManager.Sklad_zamorozkaTableAdapter = null;
            this.tableAdapterManager.SotrudnikiTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = Evro_Servis.Evro_Servis_BDDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.UsersTableAdapter = null;
            this.tableAdapterManager.Zhivaya_rybaTableAdapter = null;
            // 
            // pererabotka_koptilnyaDataGridView
            // 
            this.pererabotka_koptilnyaDataGridView.AutoGenerateColumns = false;
            this.pererabotka_koptilnyaDataGridView.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.pererabotka_koptilnyaDataGridView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.pererabotka_koptilnyaDataGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.pererabotka_koptilnyaDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.pererabotka_koptilnyaDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4});
            this.pererabotka_koptilnyaDataGridView.DataSource = this.pererabotka_koptilnyaBindingSource;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.pererabotka_koptilnyaDataGridView.DefaultCellStyle = dataGridViewCellStyle2;
            this.pererabotka_koptilnyaDataGridView.GridColor = System.Drawing.Color.WhiteSmoke;
            this.pererabotka_koptilnyaDataGridView.Location = new System.Drawing.Point(216, 246);
            this.pererabotka_koptilnyaDataGridView.Name = "pererabotka_koptilnyaDataGridView";
            this.pererabotka_koptilnyaDataGridView.RowHeadersWidth = 51;
            this.pererabotka_koptilnyaDataGridView.RowTemplate.Height = 24;
            this.pererabotka_koptilnyaDataGridView.Size = new System.Drawing.Size(1085, 384);
            this.pererabotka_koptilnyaDataGridView.TabIndex = 134;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Kod";
            this.dataGridViewTextBoxColumn1.HeaderText = "Код";
            this.dataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.Width = 90;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Naimenovanie";
            this.dataGridViewTextBoxColumn2.HeaderText = "Наименование";
            this.dataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.Width = 300;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Ves_kg";
            this.dataGridViewTextBoxColumn3.HeaderText = "Вес кг";
            this.dataGridViewTextBoxColumn3.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.Width = 250;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "FIO_koptilshika";
            this.dataGridViewTextBoxColumn4.HeaderText = "ФИО коптильщика";
            this.dataGridViewTextBoxColumn4.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.Width = 360;
            // 
            // Pererabotka_KoptilnyaAdmin
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(1582, 753);
            this.Controls.Add(this.pererabotka_koptilnyaDataGridView);
            this.Controls.Add(this.Sklady);
            this.Controls.Add(this.Pererabotka_koprilnya);
            this.Controls.Add(this.Pererabotka_razdelochnoe);
            this.Controls.Add(this.Pererabotka_zamorozka);
            this.Controls.Add(this.comboBoxFiltr);
            this.Controls.Add(this.SbrositFiltr);
            this.Controls.Add(this.Filtr);
            this.Controls.Add(this.Sohranit);
            this.Controls.Add(this.Dobavit);
            this.Controls.Add(this.Ydalit);
            this.Controls.Add(this.Poslednyaya);
            this.Controls.Add(this.Sleduushaya);
            this.Controls.Add(this.Predydushaya);
            this.Controls.Add(this.Pervaya);
            this.Controls.Add(this.Nazad);
            this.Controls.Add(this.Zhivaya_ryba);
            this.Controls.Add(this.Ryba);
            this.Controls.Add(this.Sotrudniki);
            this.Controls.Add(this.Zagolovok);
            this.Controls.Add(this.Logo);
            this.Controls.Add(this.Vyhod);
            this.Controls.Add(this.TopShapka);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Pererabotka_KoptilnyaAdmin";
            this.Text = "Евро-Сервис - Переработка коптильня";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Pererabotka_KoptilnyaAdmin_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Logo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pererabotka_koptilnyaBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.evro_Servis_BDDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pererabotka_koptilnyaDataGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label TopShapka;
        private System.Windows.Forms.Button Vyhod;
        private System.Windows.Forms.Label Zagolovok;
        private System.Windows.Forms.PictureBox Logo;
        private System.Windows.Forms.Button Zhivaya_ryba;
        private System.Windows.Forms.Button Ryba;
        private System.Windows.Forms.Button Sotrudniki;
        private System.Windows.Forms.ComboBox comboBoxFiltr;
        private System.Windows.Forms.Button SbrositFiltr;
        private System.Windows.Forms.CheckBox Filtr;
        private System.Windows.Forms.Button Sohranit;
        private System.Windows.Forms.Button Dobavit;
        private System.Windows.Forms.Button Ydalit;
        private System.Windows.Forms.Button Poslednyaya;
        private System.Windows.Forms.Button Sleduushaya;
        private System.Windows.Forms.Button Predydushaya;
        private System.Windows.Forms.Button Pervaya;
        private System.Windows.Forms.Button Nazad;
        private System.Windows.Forms.Button Sklady;
        private System.Windows.Forms.Button Pererabotka_koprilnya;
        private System.Windows.Forms.Button Pererabotka_razdelochnoe;
        private System.Windows.Forms.Button Pererabotka_zamorozka;
        private Evro_Servis_BDDataSet evro_Servis_BDDataSet;
        private System.Windows.Forms.BindingSource pererabotka_koptilnyaBindingSource;
        private Evro_Servis_BDDataSetTableAdapters.Pererabotka_koptilnyaTableAdapter pererabotka_koptilnyaTableAdapter;
        private Evro_Servis_BDDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.DataGridView pererabotka_koptilnyaDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
    }
}

