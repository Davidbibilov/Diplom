﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Evro_Servis
{
    public partial class Pererabotka_RazdelochnoeAdmin : Form
    {
        public Pererabotka_RazdelochnoeAdmin()
        {
            InitializeComponent();
        }
        private void Sotrudniki_Click(object sender, EventArgs e)
        {
            SotrudnikiAdmin fm = new SotrudnikiAdmin();
            fm.Show();
            this.Hide();
        }
        private void Zhivaya_ryba_Click(object sender, EventArgs e)
        {
            Zhivaya_rybaAdmin fm = new Zhivaya_rybaAdmin();
            fm.Show();
            this.Hide();
        }

        private void Ryba_Click(object sender, EventArgs e)
        {
            RybaAdmin fm = new RybaAdmin();
            fm.Show();
            this.Hide();
        }
        private void Pererabotka_koprilnya_Click(object sender, EventArgs e)
        {
            Pererabotka_KoptilnyaAdmin fm = new Pererabotka_KoptilnyaAdmin();
            fm.Show();
            this.Hide();
        }

        private void Pererabotka_razdelochnoe_Click(object sender, EventArgs e)
        {
            Pererabotka_RazdelochnoeAdmin fm = new Pererabotka_RazdelochnoeAdmin();
            fm.Show();
            this.Hide();
        }

        private void Pererabotka_zamorozka_Click(object sender, EventArgs e)
        {
            Pererabotka_ZamorozkaAdmin fm = new Pererabotka_ZamorozkaAdmin();
            fm.Show();
            this.Hide();
        }

        private void Sklady_Click(object sender, EventArgs e)
        {
            Sklad_koptilnyaAdmin fm = new Sklad_koptilnyaAdmin();
            fm.Show();
            this.Hide();
        }

        private void Vyhod_Click(object sender, EventArgs e)
        {
            AvtorizaciyaFM fm = new AvtorizaciyaFM();
            fm.Show();
            this.Hide();
        }
        private void Pervaya_Click(object sender, EventArgs e)
        {
            pererabotka_razdelochnoyeBindingSource.MoveFirst();
        }

        private void Sleduushaya_Click(object sender, EventArgs e)
        {
            pererabotka_razdelochnoyeBindingSource.MoveNext();
        }

        private void Predydushaya_Click(object sender, EventArgs e)
        {
            pererabotka_razdelochnoyeBindingSource.MovePrevious();
        }

        private void Poslednyaya_Click(object sender, EventArgs e)
        {
            pererabotka_razdelochnoyeBindingSource.MoveLast();
        }

        private void Dobavit_Click(object sender, EventArgs e)
        {
            pererabotka_razdelochnoyeBindingSource.AddNew();
        }

        private void Ydalit_Click(object sender, EventArgs e)
        {
            pererabotka_razdelochnoyeBindingSource.RemoveCurrent();
        }

        private void Sohranit_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.pererabotka_razdelochnoyeBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.evro_Servis_BDDataSet);
        }

        private void Nazad_Click(object sender, EventArgs e)
        {
            MenuAdmin fm = new MenuAdmin();
            fm.Show();
            this.Hide();
        }
        private void Filtr_CheckedChanged(object sender, EventArgs e)
        {
            pererabotka_razdelochnoyeBindingSource.Filter = "Naimenovanie='" + comboBoxFiltr.Text + "'";
        }
        private void SbrositFiltr_Click(object sender, EventArgs e)
        {
            pererabotka_razdelochnoyeBindingSource.Filter = "";
        }
        private void Pererabotka_RazdelochnoeAdmin_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "evro_Servis_BDDataSet.Pererabotka_razdelochnoye". При необходимости она может быть перемещена или удалена.
            this.pererabotka_razdelochnoyeTableAdapter.Fill(this.evro_Servis_BDDataSet.Pererabotka_razdelochnoye);

        }
    }
}