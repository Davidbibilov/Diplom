﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Evro_Servis
{
    public partial class RybaUser : Form
    {
        public RybaUser()
        {
            InitializeComponent();
        }
        private void SotrudnikiAdmin_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "evro_Servis_BDDataSet.Ryba". При необходимости она может быть перемещена или удалена.
            this.rybaTableAdapter.Fill(this.evro_Servis_BDDataSet.Ryba);

        }

        private void Sotrudniki_Click_1(object sender, EventArgs e)
        {
            SotrudnikiUser fm = new SotrudnikiUser();
            fm.Show();
            this.Hide();
        }

        private void Sklady_Click_1(object sender, EventArgs e)
        {
            Sklad_koptilnyaUser fm = new Sklad_koptilnyaUser();
            fm.Show();
            this.Hide();
        }

        private void Ryba_Click_1(object sender, EventArgs e)
        {
            RybaUser fm = new RybaUser();
            fm.Show();
            this.Hide();
        }
        private void Pererabotka_Click_1(object sender, EventArgs e)
        {
            Pererabotka_KoptilnyaUser fm = new Pererabotka_KoptilnyaUser();
            fm.Show();
            this.Hide();
        }
        private void Vyhod_Click(object sender, EventArgs e)
        {
            AvtorizaciyaFM fm = new AvtorizaciyaFM();
            fm.Show();
            this.Hide();
        }

        private void Pervaya_Click(object sender, EventArgs e)
        {
            rybaBindingSource.MoveFirst();
        }

        private void Sleduushaya_Click(object sender, EventArgs e)
        {
            rybaBindingSource.MoveNext();
        }

        private void Predydushaya_Click(object sender, EventArgs e)
        {
            rybaBindingSource.MovePrevious();
        }

        private void Poslednyaya_Click(object sender, EventArgs e)
        {
            rybaBindingSource.MoveLast();
        }
        private void Nazad_Click(object sender, EventArgs e)
        {
            MenuUser fm = new MenuUser();
            fm.Show();
            this.Hide();
        }
        private void Poisk_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < rybaDataGridView.ColumnCount - 1; i++)
            {
                for (int j = 0; j < rybaDataGridView.RowCount - 1; j++)
                {
                    rybaDataGridView[i, j].Style.BackColor = Color.White;
                    rybaDataGridView[i, j].Style.BackColor = Color.Gray;
                }
            }
            for (int i = 0; i < rybaDataGridView.ColumnCount - 1; i++)
            {
                for (int j = 0; j < rybaDataGridView.ColumnCount - 1; j++)
                {
                    if (rybaDataGridView[i, j].Value.ToString().IndexOf(StrokaPoiska.Text) != -1)
                    {
                        rybaDataGridView[i, j].Style.BackColor = Color.AliceBlue;
                        rybaDataGridView[i, j].Style.ForeColor = Color.Blue;
                    }
                }
            }
        }
        private void Filtr_CheckedChanged(object sender, EventArgs e)
        {
            rybaBindingSource.Filter = "Naimenovanie='" + comboBoxFiltr.Text + "'";
        }
        private System.Windows.Forms.DataGridViewColumn COL;
        private void Sortirovka_Click(object sender, EventArgs e)
        {
            COL = new System.Windows.Forms.DataGridViewColumn();
            {
                switch (listBox.SelectedIndex)
                {
                    case 0:
                        COL = dataGridViewTextBoxColumn2;
                        break;
                    case 1:
                        COL = dataGridViewTextBoxColumn3;
                        break;
                    case 2:
                        COL = dataGridViewTextBoxColumn4;
                        break;
                }
                if (PoVozrastaniu.Checked)
                    rybaDataGridView.Sort(COL, System.ComponentModel.ListSortDirection.Ascending);
                else
                    rybaDataGridView.Sort(COL, System.ComponentModel.ListSortDirection.Descending);
            }
        }
        private void SbrositFiltr_Click(object sender, EventArgs e)
        {
            rybaBindingSource.Filter = "";
        }
    }
}