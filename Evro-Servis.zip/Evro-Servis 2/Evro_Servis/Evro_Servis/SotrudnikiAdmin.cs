﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Evro_Servis
{
    public partial class SotrudnikiAdmin : Form
    {
        public SotrudnikiAdmin()
        {
            InitializeComponent();
        }
        private void SotrudnikiAdmin_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "evro_Servis_BDDataSet.Sotrudniki". При необходимости она может быть перемещена или удалена.
            this.sotrudnikiTableAdapter.Fill(this.evro_Servis_BDDataSet.Sotrudniki);

        }
        private void Sotrudniki_Click(object sender, EventArgs e)
        {
            SotrudnikiAdmin fm = new SotrudnikiAdmin();
            fm.Show();
            this.Hide();
        }

        private void Otchet_proizvodstva_Click(object sender, EventArgs e)
        {
            OtchetProizvodstvaAdmin fm = new OtchetProizvodstvaAdmin();
            fm.Show();
            this.Hide();
        }

        private void Sklady_Click(object sender, EventArgs e)
        {
            Sklad_koptilnyaAdmin fm = new Sklad_koptilnyaAdmin();
            fm.Show();
            this.Hide();
        }

        private void Ryba_Click(object sender, EventArgs e)
        {
            RybaAdmin fm = new RybaAdmin();
            fm.Show();
            this.Hide();
        }

        private void Zhivaya_ryba_Click(object sender, EventArgs e)
        {
            Zhivaya_rybaAdmin fm = new Zhivaya_rybaAdmin();
            fm.Show();
            this.Hide();
        }

        private void Pererabotka_Click(object sender, EventArgs e)
        {
            Pererabotka_KoptilnyaAdmin fm = new Pererabotka_KoptilnyaAdmin();
            fm.Show();
            this.Hide();
        }

        private void Vyhod_Click(object sender, EventArgs e)
        {
            AvtorizaciyaFM fm = new AvtorizaciyaFM();
            fm.Show();
            this.Hide();
        }

        private void Pervaya_Click(object sender, EventArgs e)
        {
            sotrudnikiBindingSource.MoveFirst();
        }

        private void Sleduushaya_Click(object sender, EventArgs e)
        {
            sotrudnikiBindingSource.MoveNext();
        }

        private void Predydushaya_Click(object sender, EventArgs e)
        {
            sotrudnikiBindingSource.MovePrevious();
        }

        private void Poslednyaya_Click(object sender, EventArgs e)
        {
            sotrudnikiBindingSource.MoveLast();
        }

        private void Dobavit_Click(object sender, EventArgs e)
        {
            sotrudnikiBindingSource.AddNew();
        }

        private void Ydalit_Click(object sender, EventArgs e)
        {
            sotrudnikiBindingSource.RemoveCurrent();
        }

        private void Sohranit_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.sotrudnikiBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.evro_Servis_BDDataSet);
        }

        private void Nazad_Click(object sender, EventArgs e)
        {
            MenuAdmin fm = new MenuAdmin();
            fm.Show();
            this.Hide();
        }
        private void Poisk_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < sotrudnikiDataGridView.ColumnCount - 1; i++)
            {
                for (int j = 0; j < sotrudnikiDataGridView.RowCount - 1; j++)
                {
                    sotrudnikiDataGridView[i, j].Style.BackColor = Color.White;
                    sotrudnikiDataGridView[i, j].Style.BackColor = Color.Gray;
                }
            }
            for (int i = 0; i < sotrudnikiDataGridView.ColumnCount - 1; i++)
            {
                for (int j = 0; j < sotrudnikiDataGridView.ColumnCount - 1; j++)
                {
                    if (sotrudnikiDataGridView[i, j].Value.ToString().IndexOf(StrokaPoiska.Text) != -1)
                    {
                        sotrudnikiDataGridView[i, j].Style.BackColor = Color.AliceBlue;
                        sotrudnikiDataGridView[i, j].Style.ForeColor = Color.Blue;
                    }
                }
            }
        }
        private void Filtr_CheckedChanged(object sender, EventArgs e)
        {
            sotrudnikiBindingSource.Filter = "Dolzhnost='" + comboBoxFiltr.Text + "'";
        }
        private System.Windows.Forms.DataGridViewColumn COL;
        private void Sortirovka_Click(object sender, EventArgs e)
        {
            COL = new System.Windows.Forms.DataGridViewColumn();
            {

                switch (listBox.SelectedIndex)
                {

                    case 0:
                        COL = dataGridViewTextBoxColumn2;
                        break;
                    case 1:
                        COL = dataGridViewTextBoxColumn3;
                        break;
                    case 2:
                        COL = dataGridViewTextBoxColumn4;
                        break;
                    case 3:
                        COL = dataGridViewTextBoxColumn5;
                        break;
                }
                if (PoVozrastaniu.Checked)
                    sotrudnikiDataGridView.Sort(COL, System.ComponentModel.ListSortDirection.Ascending);
                else
                    sotrudnikiDataGridView.Sort(COL, System.ComponentModel.ListSortDirection.Descending);
            }
        }

        private void SbrositFiltr_Click(object sender, EventArgs e)
        {
            sotrudnikiBindingSource.Filter = "";
        }
    }
}