﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Evro_Servis
{
    public partial class MenuAdmin : Form
    {
        public MenuAdmin()
        {
            InitializeComponent();
        }

        private void Sotrudniki_Click(object sender, EventArgs e)
        {
            SotrudnikiAdmin fm = new SotrudnikiAdmin();
            fm.Show();
            this.Hide();

        }

        private void Ryba_Click(object sender, EventArgs e)
        {
            RybaAdmin fm = new RybaAdmin();
            fm.Show();
            this.Hide();
        }

        private void Pererabotka_zamorozka_Click(object sender, EventArgs e)
        {
            Pererabotka_ZamorozkaAdmin fm = new Pererabotka_ZamorozkaAdmin();
            fm.Show();
            this.Hide();
        }

        private void Pererabotka_koptilnya_Click(object sender, EventArgs e)
        {
            Pererabotka_KoptilnyaAdmin fm = new Pererabotka_KoptilnyaAdmin();
            fm.Show();
            this.Hide();
        }

        private void Pererabotka_razdelochnoe_Click(object sender, EventArgs e)
        {
            Pererabotka_RazdelochnoeAdmin fm = new Pererabotka_RazdelochnoeAdmin();
            fm.Show();
            this.Hide();
        }

        private void Vyhod_Click(object sender, EventArgs e)
        {
            AvtorizaciyaFM fm = new AvtorizaciyaFM();
            fm.Show();
            this.Hide();
        }

        private void Zhivaya_ryba_Click(object sender, EventArgs e)
        {
            Zhivaya_rybaAdmin fm = new Zhivaya_rybaAdmin();
            fm.Show();
            this.Hide();
        }

        private void Otchet_proizvodstvo_Click(object sender, EventArgs e)
        {
            OtchetProizvodstvaAdmin fm = new OtchetProizvodstvaAdmin();
            fm.Show();
            this.Hide();
        }

        private void Sklad_koptilnya_Click(object sender, EventArgs e)
        {
            Sklad_koptilnyaAdmin fm = new Sklad_koptilnyaAdmin();
            fm.Show();
            this.Hide();
        }

        private void Sklad_zamorozka_Click(object sender, EventArgs e)
        {
            Sklad_zamorozkaAdmin fm = new Sklad_zamorozkaAdmin();
            fm.Show();
            this.Hide();
        }

        private void Sklad_razdelochnoe_Click(object sender, EventArgs e)
        {
            Sklad_razdelochnoeAdmin fm = new Sklad_razdelochnoeAdmin();
            fm.Show();
            this.Hide();
        }
    }
}
