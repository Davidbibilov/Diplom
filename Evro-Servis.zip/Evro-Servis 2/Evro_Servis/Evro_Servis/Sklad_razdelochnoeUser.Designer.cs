﻿
namespace Evro_Servis
{
    partial class Sklad_razdelochnoeUser
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Sklad_razdelochnoeUser));
            this.TopShapka = new System.Windows.Forms.Label();
            this.Vyhod = new System.Windows.Forms.Button();
            this.Zagolovok = new System.Windows.Forms.Label();
            this.Logo = new System.Windows.Forms.PictureBox();
            this.Ryba = new System.Windows.Forms.Button();
            this.Sotrudniki = new System.Windows.Forms.Button();
            this.Pererabotka = new System.Windows.Forms.Button();
            this.Sklad_koprilnya = new System.Windows.Forms.Button();
            this.Sklad_razdelochnoe = new System.Windows.Forms.Button();
            this.Sklad_zamorozka = new System.Windows.Forms.Button();
            this.comboBoxFiltr = new System.Windows.Forms.ComboBox();
            this.SbrositFiltr = new System.Windows.Forms.Button();
            this.Filtr = new System.Windows.Forms.CheckBox();
            this.Poslednyaya = new System.Windows.Forms.Button();
            this.Sleduushaya = new System.Windows.Forms.Button();
            this.Predydushaya = new System.Windows.Forms.Button();
            this.Pervaya = new System.Windows.Forms.Button();
            this.Nazad = new System.Windows.Forms.Button();
            this.evro_Servis_BDDataSet = new Evro_Servis.Evro_Servis_BDDataSet();
            this.sklad_razdelochnoyeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sklad_razdelochnoyeTableAdapter = new Evro_Servis.Evro_Servis_BDDataSetTableAdapters.Sklad_razdelochnoyeTableAdapter();
            this.tableAdapterManager = new Evro_Servis.Evro_Servis_BDDataSetTableAdapters.TableAdapterManager();
            this.sklad_razdelochnoyeDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.Logo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.evro_Servis_BDDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sklad_razdelochnoyeBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sklad_razdelochnoyeDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // TopShapka
            // 
            this.TopShapka.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.TopShapka.Location = new System.Drawing.Point(-5, -1);
            this.TopShapka.Name = "TopShapka";
            this.TopShapka.Size = new System.Drawing.Size(1592, 157);
            this.TopShapka.TabIndex = 70;
            // 
            // Vyhod
            // 
            this.Vyhod.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Vyhod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Vyhod.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Vyhod.ForeColor = System.Drawing.Color.Yellow;
            this.Vyhod.Location = new System.Drawing.Point(1232, 12);
            this.Vyhod.Name = "Vyhod";
            this.Vyhod.Size = new System.Drawing.Size(294, 62);
            this.Vyhod.TabIndex = 81;
            this.Vyhod.Text = "Выход";
            this.Vyhod.UseVisualStyleBackColor = false;
            this.Vyhod.Click += new System.EventHandler(this.Vyhod_Click);
            // 
            // Zagolovok
            // 
            this.Zagolovok.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Zagolovok.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Zagolovok.ForeColor = System.Drawing.Color.White;
            this.Zagolovok.Location = new System.Drawing.Point(12, 80);
            this.Zagolovok.Name = "Zagolovok";
            this.Zagolovok.Size = new System.Drawing.Size(326, 62);
            this.Zagolovok.TabIndex = 74;
            this.Zagolovok.Text = "Разделочное";
            this.Zagolovok.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Logo
            // 
            this.Logo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Logo.Image = global::Evro_Servis.Properties.Resources.LogoFM;
            this.Logo.Location = new System.Drawing.Point(12, 12);
            this.Logo.Name = "Logo";
            this.Logo.Size = new System.Drawing.Size(326, 62);
            this.Logo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Logo.TabIndex = 73;
            this.Logo.TabStop = false;
            // 
            // Ryba
            // 
            this.Ryba.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Ryba.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Ryba.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Ryba.ForeColor = System.Drawing.Color.White;
            this.Ryba.Location = new System.Drawing.Point(640, 12);
            this.Ryba.Name = "Ryba";
            this.Ryba.Size = new System.Drawing.Size(290, 62);
            this.Ryba.TabIndex = 102;
            this.Ryba.Text = "Рыба";
            this.Ryba.UseVisualStyleBackColor = false;
            this.Ryba.Click += new System.EventHandler(this.Ryba_Click);
            // 
            // Sotrudniki
            // 
            this.Sotrudniki.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Sotrudniki.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Sotrudniki.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Sotrudniki.ForeColor = System.Drawing.Color.White;
            this.Sotrudniki.Location = new System.Drawing.Point(344, 12);
            this.Sotrudniki.Name = "Sotrudniki";
            this.Sotrudniki.Size = new System.Drawing.Size(290, 62);
            this.Sotrudniki.TabIndex = 101;
            this.Sotrudniki.Text = "Сотрудники";
            this.Sotrudniki.UseVisualStyleBackColor = false;
            this.Sotrudniki.Click += new System.EventHandler(this.Sotrudniki_Click);
            // 
            // Pererabotka
            // 
            this.Pererabotka.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Pererabotka.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Pererabotka.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Pererabotka.ForeColor = System.Drawing.Color.White;
            this.Pererabotka.Location = new System.Drawing.Point(936, 12);
            this.Pererabotka.Name = "Pererabotka";
            this.Pererabotka.Size = new System.Drawing.Size(290, 62);
            this.Pererabotka.TabIndex = 109;
            this.Pererabotka.Text = "Переработка";
            this.Pererabotka.UseVisualStyleBackColor = false;
            this.Pererabotka.Click += new System.EventHandler(this.Pererabotka_Click);
            // 
            // Sklad_koprilnya
            // 
            this.Sklad_koprilnya.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Sklad_koprilnya.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Sklad_koprilnya.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Sklad_koprilnya.ForeColor = System.Drawing.Color.White;
            this.Sklad_koprilnya.Location = new System.Drawing.Point(344, 80);
            this.Sklad_koprilnya.Name = "Sklad_koprilnya";
            this.Sklad_koprilnya.Size = new System.Drawing.Size(390, 62);
            this.Sklad_koprilnya.TabIndex = 108;
            this.Sklad_koprilnya.Text = "Склад коптильня";
            this.Sklad_koprilnya.UseVisualStyleBackColor = false;
            this.Sklad_koprilnya.Click += new System.EventHandler(this.Sklad_koprilnya_Click);
            // 
            // Sklad_razdelochnoe
            // 
            this.Sklad_razdelochnoe.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Sklad_razdelochnoe.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Sklad_razdelochnoe.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Sklad_razdelochnoe.ForeColor = System.Drawing.Color.White;
            this.Sklad_razdelochnoe.Location = new System.Drawing.Point(1136, 80);
            this.Sklad_razdelochnoe.Name = "Sklad_razdelochnoe";
            this.Sklad_razdelochnoe.Size = new System.Drawing.Size(390, 62);
            this.Sklad_razdelochnoe.TabIndex = 107;
            this.Sklad_razdelochnoe.Text = "Склад разделочное";
            this.Sklad_razdelochnoe.UseVisualStyleBackColor = false;
            this.Sklad_razdelochnoe.Click += new System.EventHandler(this.Sklad_razdelochnoe_Click);
            // 
            // Sklad_zamorozka
            // 
            this.Sklad_zamorozka.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Sklad_zamorozka.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Sklad_zamorozka.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Sklad_zamorozka.ForeColor = System.Drawing.Color.White;
            this.Sklad_zamorozka.Location = new System.Drawing.Point(740, 80);
            this.Sklad_zamorozka.Name = "Sklad_zamorozka";
            this.Sklad_zamorozka.Size = new System.Drawing.Size(390, 62);
            this.Sklad_zamorozka.TabIndex = 106;
            this.Sklad_zamorozka.Text = "Склад заморозка";
            this.Sklad_zamorozka.UseVisualStyleBackColor = false;
            this.Sklad_zamorozka.Click += new System.EventHandler(this.Sklad_zamorozka_Click);
            // 
            // comboBoxFiltr
            // 
            this.comboBoxFiltr.DataSource = this.sklad_razdelochnoyeBindingSource;
            this.comboBoxFiltr.DisplayMember = "Naimenovanie";
            this.comboBoxFiltr.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBoxFiltr.FormattingEnabled = true;
            this.comboBoxFiltr.Location = new System.Drawing.Point(1031, 188);
            this.comboBoxFiltr.Name = "comboBoxFiltr";
            this.comboBoxFiltr.Size = new System.Drawing.Size(271, 39);
            this.comboBoxFiltr.TabIndex = 129;
            // 
            // SbrositFiltr
            // 
            this.SbrositFiltr.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.SbrositFiltr.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.SbrositFiltr.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.SbrositFiltr.ForeColor = System.Drawing.Color.White;
            this.SbrositFiltr.Location = new System.Drawing.Point(1307, 244);
            this.SbrositFiltr.Name = "SbrositFiltr";
            this.SbrositFiltr.Size = new System.Drawing.Size(219, 62);
            this.SbrositFiltr.TabIndex = 128;
            this.SbrositFiltr.Text = "Сбросить";
            this.SbrositFiltr.UseVisualStyleBackColor = false;
            this.SbrositFiltr.Click += new System.EventHandler(this.SbrositFiltr_Click);
            // 
            // Filtr
            // 
            this.Filtr.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Filtr.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Filtr.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Filtr.ForeColor = System.Drawing.Color.White;
            this.Filtr.Location = new System.Drawing.Point(1308, 177);
            this.Filtr.Name = "Filtr";
            this.Filtr.Size = new System.Drawing.Size(218, 62);
            this.Filtr.TabIndex = 127;
            this.Filtr.Text = "Фильтровать";
            this.Filtr.UseVisualStyleBackColor = false;
            this.Filtr.CheckedChanged += new System.EventHandler(this.Filtr_CheckedChanged);
            // 
            // Poslednyaya
            // 
            this.Poslednyaya.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Poslednyaya.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Poslednyaya.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Poslednyaya.ForeColor = System.Drawing.Color.White;
            this.Poslednyaya.Location = new System.Drawing.Point(968, 675);
            this.Poslednyaya.Name = "Poslednyaya";
            this.Poslednyaya.Size = new System.Drawing.Size(192, 62);
            this.Poslednyaya.TabIndex = 123;
            this.Poslednyaya.Text = "Последняя";
            this.Poslednyaya.UseVisualStyleBackColor = false;
            this.Poslednyaya.Click += new System.EventHandler(this.Poslednyaya_Click);
            // 
            // Sleduushaya
            // 
            this.Sleduushaya.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Sleduushaya.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Sleduushaya.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Sleduushaya.ForeColor = System.Drawing.Color.White;
            this.Sleduushaya.Location = new System.Drawing.Point(770, 636);
            this.Sleduushaya.Name = "Sleduushaya";
            this.Sleduushaya.Size = new System.Drawing.Size(192, 62);
            this.Sleduushaya.TabIndex = 122;
            this.Sleduushaya.Text = "Следующая";
            this.Sleduushaya.UseVisualStyleBackColor = false;
            this.Sleduushaya.Click += new System.EventHandler(this.Sleduushaya_Click);
            // 
            // Predydushaya
            // 
            this.Predydushaya.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Predydushaya.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Predydushaya.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Predydushaya.ForeColor = System.Drawing.Color.White;
            this.Predydushaya.Location = new System.Drawing.Point(572, 636);
            this.Predydushaya.Name = "Predydushaya";
            this.Predydushaya.Size = new System.Drawing.Size(192, 62);
            this.Predydushaya.TabIndex = 121;
            this.Predydushaya.Text = "Предыдущая";
            this.Predydushaya.UseVisualStyleBackColor = false;
            this.Predydushaya.Click += new System.EventHandler(this.Predydushaya_Click);
            // 
            // Pervaya
            // 
            this.Pervaya.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Pervaya.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Pervaya.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Pervaya.ForeColor = System.Drawing.Color.White;
            this.Pervaya.Location = new System.Drawing.Point(374, 675);
            this.Pervaya.Name = "Pervaya";
            this.Pervaya.Size = new System.Drawing.Size(192, 62);
            this.Pervaya.TabIndex = 120;
            this.Pervaya.Text = "Первая";
            this.Pervaya.UseVisualStyleBackColor = false;
            this.Pervaya.Click += new System.EventHandler(this.Pervaya_Click);
            // 
            // Nazad
            // 
            this.Nazad.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Nazad.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Nazad.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Nazad.ForeColor = System.Drawing.Color.Yellow;
            this.Nazad.Location = new System.Drawing.Point(18, 175);
            this.Nazad.Name = "Nazad";
            this.Nazad.Size = new System.Drawing.Size(192, 62);
            this.Nazad.TabIndex = 119;
            this.Nazad.Text = "Назад";
            this.Nazad.UseVisualStyleBackColor = false;
            this.Nazad.Click += new System.EventHandler(this.Nazad_Click);
            // 
            // evro_Servis_BDDataSet
            // 
            this.evro_Servis_BDDataSet.DataSetName = "Evro_Servis_BDDataSet";
            this.evro_Servis_BDDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // sklad_razdelochnoyeBindingSource
            // 
            this.sklad_razdelochnoyeBindingSource.DataMember = "Sklad_razdelochnoye";
            this.sklad_razdelochnoyeBindingSource.DataSource = this.evro_Servis_BDDataSet;
            // 
            // sklad_razdelochnoyeTableAdapter
            // 
            this.sklad_razdelochnoyeTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.Otchety_proizvodstvoTableAdapter = null;
            this.tableAdapterManager.Pererabotka_koptilnyaTableAdapter = null;
            this.tableAdapterManager.Pererabotka_razdelochnoyeTableAdapter = null;
            this.tableAdapterManager.Pererabotka_zamorozkaTableAdapter = null;
            this.tableAdapterManager.Proizvodstvo_vyrashivaniyeTableAdapter = null;
            this.tableAdapterManager.RybaTableAdapter = null;
            this.tableAdapterManager.Sklad_koptilnyaTableAdapter = null;
            this.tableAdapterManager.Sklad_razdelochnoyeTableAdapter = this.sklad_razdelochnoyeTableAdapter;
            this.tableAdapterManager.Sklad_zamorozkaTableAdapter = null;
            this.tableAdapterManager.SotrudnikiTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = Evro_Servis.Evro_Servis_BDDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.UsersTableAdapter = null;
            this.tableAdapterManager.Zhivaya_rybaTableAdapter = null;
            // 
            // sklad_razdelochnoyeDataGridView
            // 
            this.sklad_razdelochnoyeDataGridView.AutoGenerateColumns = false;
            this.sklad_razdelochnoyeDataGridView.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.sklad_razdelochnoyeDataGridView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.sklad_razdelochnoyeDataGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.sklad_razdelochnoyeDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.sklad_razdelochnoyeDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4});
            this.sklad_razdelochnoyeDataGridView.DataSource = this.sklad_razdelochnoyeBindingSource;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.sklad_razdelochnoyeDataGridView.DefaultCellStyle = dataGridViewCellStyle2;
            this.sklad_razdelochnoyeDataGridView.GridColor = System.Drawing.Color.WhiteSmoke;
            this.sklad_razdelochnoyeDataGridView.Location = new System.Drawing.Point(216, 246);
            this.sklad_razdelochnoyeDataGridView.Name = "sklad_razdelochnoyeDataGridView";
            this.sklad_razdelochnoyeDataGridView.RowHeadersWidth = 51;
            this.sklad_razdelochnoyeDataGridView.RowTemplate.Height = 24;
            this.sklad_razdelochnoyeDataGridView.Size = new System.Drawing.Size(1085, 384);
            this.sklad_razdelochnoyeDataGridView.TabIndex = 130;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Kod";
            this.dataGridViewTextBoxColumn1.HeaderText = "Код";
            this.dataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.Width = 90;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Naimenovanie";
            this.dataGridViewTextBoxColumn2.HeaderText = "Наименование";
            this.dataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.Width = 350;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Kolichestvo";
            this.dataGridViewTextBoxColumn3.HeaderText = "Количество";
            this.dataGridViewTextBoxColumn3.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.Width = 200;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "FIO_kladovshika";
            this.dataGridViewTextBoxColumn4.HeaderText = "ФИО кладовщика";
            this.dataGridViewTextBoxColumn4.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.Width = 350;
            // 
            // Sklad_razdelochnoeUser
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(1582, 753);
            this.Controls.Add(this.sklad_razdelochnoyeDataGridView);
            this.Controls.Add(this.comboBoxFiltr);
            this.Controls.Add(this.SbrositFiltr);
            this.Controls.Add(this.Filtr);
            this.Controls.Add(this.Poslednyaya);
            this.Controls.Add(this.Sleduushaya);
            this.Controls.Add(this.Predydushaya);
            this.Controls.Add(this.Pervaya);
            this.Controls.Add(this.Nazad);
            this.Controls.Add(this.Pererabotka);
            this.Controls.Add(this.Sklad_koprilnya);
            this.Controls.Add(this.Sklad_razdelochnoe);
            this.Controls.Add(this.Sklad_zamorozka);
            this.Controls.Add(this.Ryba);
            this.Controls.Add(this.Sotrudniki);
            this.Controls.Add(this.Zagolovok);
            this.Controls.Add(this.Logo);
            this.Controls.Add(this.Vyhod);
            this.Controls.Add(this.TopShapka);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Sklad_razdelochnoeUser";
            this.Text = "Евро-Сервис - Склад разделочное";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Sklad_koptilnyaAdmin_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Logo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.evro_Servis_BDDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sklad_razdelochnoyeBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sklad_razdelochnoyeDataGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label TopShapka;
        private System.Windows.Forms.Button Vyhod;
        private System.Windows.Forms.Label Zagolovok;
        private System.Windows.Forms.PictureBox Logo;
        private System.Windows.Forms.Button Ryba;
        private System.Windows.Forms.Button Sotrudniki;
        private System.Windows.Forms.Button Pererabotka;
        private System.Windows.Forms.Button Sklad_koprilnya;
        private System.Windows.Forms.Button Sklad_razdelochnoe;
        private System.Windows.Forms.Button Sklad_zamorozka;
        private System.Windows.Forms.ComboBox comboBoxFiltr;
        private System.Windows.Forms.Button SbrositFiltr;
        private System.Windows.Forms.CheckBox Filtr;
        private System.Windows.Forms.Button Poslednyaya;
        private System.Windows.Forms.Button Sleduushaya;
        private System.Windows.Forms.Button Predydushaya;
        private System.Windows.Forms.Button Pervaya;
        private System.Windows.Forms.Button Nazad;
        private Evro_Servis_BDDataSet evro_Servis_BDDataSet;
        private System.Windows.Forms.BindingSource sklad_razdelochnoyeBindingSource;
        private Evro_Servis_BDDataSetTableAdapters.Sklad_razdelochnoyeTableAdapter sklad_razdelochnoyeTableAdapter;
        private Evro_Servis_BDDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.DataGridView sklad_razdelochnoyeDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
    }
}

