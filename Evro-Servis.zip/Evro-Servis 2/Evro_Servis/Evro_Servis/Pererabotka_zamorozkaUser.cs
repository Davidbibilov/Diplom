﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Evro_Servis
{
    public partial class Pererabotka_zamorozkaUser : Form
    {
        public Pererabotka_zamorozkaUser()
        {
            InitializeComponent();
        }
        private void Sotrudniki_Click(object sender, EventArgs e)
        {
            SotrudnikiUser fm = new SotrudnikiUser();
            fm.Show();
            this.Hide();

        }

        private void Ryba_Click(object sender, EventArgs e)
        {
            RybaUser fm = new RybaUser();
            fm.Show();
            this.Hide();
        }

        private void Pererabotka_zamorozka_Click(object sender, EventArgs e)
        {
            Pererabotka_zamorozkaUser fm = new Pererabotka_zamorozkaUser();
            fm.Show();
            this.Hide();
        }

        private void Pererabotka_koprilnya_Click(object sender, EventArgs e)
        {
            Pererabotka_KoptilnyaUser fm = new Pererabotka_KoptilnyaUser();
            fm.Show();
            this.Hide();
        }

        private void Pererabotka_razdelochnoe_Click(object sender, EventArgs e)
        {
            Pererabotka_RazdelochnoeUser fm = new Pererabotka_RazdelochnoeUser();
            fm.Show();
            this.Hide();
        }

        private void Sklady_Click(object sender, EventArgs e)
        {
            Sklad_koptilnyaUser fm = new Sklad_koptilnyaUser();
            fm.Show();
            this.Hide();
        }

        private void Vyhod_Click(object sender, EventArgs e)
        {
            AvtorizaciyaFM fm = new AvtorizaciyaFM();
            fm.Show();
            this.Hide();
        }
        private void Pervaya_Click(object sender, EventArgs e)
        {
            pererabotka_zamorozkaBindingSource.MoveFirst();
        }

        private void Sleduushaya_Click(object sender, EventArgs e)
        {
            pererabotka_zamorozkaBindingSource.MoveNext();
        }

        private void Predydushaya_Click(object sender, EventArgs e)
        {
            pererabotka_zamorozkaBindingSource.MovePrevious();
        }

        private void Poslednyaya_Click(object sender, EventArgs e)
        {
            pererabotka_zamorozkaBindingSource.MoveLast();
        }

        private void Nazad_Click(object sender, EventArgs e)
        {
            MenuAdmin fm = new MenuAdmin();
            fm.Show();
            this.Hide();
        }
        private void Filtr_CheckedChanged(object sender, EventArgs e)
        {
            pererabotka_zamorozkaBindingSource.Filter = "Naimenovanie='" + comboBoxFiltr.Text + "'";
        }
        private void SbrositFiltr_Click(object sender, EventArgs e)
        {
            pererabotka_zamorozkaBindingSource.Filter = "";
        }
        private void Pererabotka_KoptilnyaAdmin_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "evro_Servis_BDDataSet.Pererabotka_zamorozka". При необходимости она может быть перемещена или удалена.
            this.pererabotka_zamorozkaTableAdapter.Fill(this.evro_Servis_BDDataSet.Pererabotka_zamorozka);

        }
    }
}