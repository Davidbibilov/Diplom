﻿
namespace Evro_Servis
{
    partial class Titulnaya
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Titulnaya));
            this.Avtorizaciya = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.text2 = new System.Windows.Forms.Label();
            this.text1 = new System.Windows.Forms.Label();
            this.TopShapka = new System.Windows.Forms.Label();
            this.Vyiti = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // Avtorizaciya
            // 
            this.Avtorizaciya.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Avtorizaciya.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Avtorizaciya.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Avtorizaciya.ForeColor = System.Drawing.Color.Yellow;
            this.Avtorizaciya.Location = new System.Drawing.Point(1012, 650);
            this.Avtorizaciya.Name = "Avtorizaciya";
            this.Avtorizaciya.Size = new System.Drawing.Size(362, 74);
            this.Avtorizaciya.TabIndex = 75;
            this.Avtorizaciya.Text = "Авторизация";
            this.Avtorizaciya.UseVisualStyleBackColor = false;
            this.Avtorizaciya.Click += new System.EventHandler(this.Avtorizaciya_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.pictureBox1.Image = global::Evro_Servis.Properties.Resources.LogoFM_blue;
            this.pictureBox1.Location = new System.Drawing.Point(437, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(705, 132);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 74;
            this.pictureBox1.TabStop = false;
            // 
            // text2
            // 
            this.text2.BackColor = System.Drawing.Color.Transparent;
            this.text2.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.text2.ForeColor = System.Drawing.Color.Black;
            this.text2.Location = new System.Drawing.Point(151, 426);
            this.text2.Name = "text2";
            this.text2.Size = new System.Drawing.Size(1291, 179);
            this.text2.TabIndex = 72;
            this.text2.Text = "Главной целью коммерческой деятельности является получение прибыли через удовлетв" +
    "орение покупательского спроса при высокой культуре торгового обслуживания. ";
            // 
            // text1
            // 
            this.text1.BackColor = System.Drawing.Color.Transparent;
            this.text1.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.text1.ForeColor = System.Drawing.Color.Black;
            this.text1.Location = new System.Drawing.Point(151, 274);
            this.text1.Name = "text1";
            this.text1.Size = new System.Drawing.Size(1291, 121);
            this.text1.TabIndex = 71;
            this.text1.Text = "ООО \"Евро-Сервис\" – комплекс деятельности фирмы по созданию, производству и довед" +
    "ению товара до потребителя.";
            // 
            // TopShapka
            // 
            this.TopShapka.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.TopShapka.Location = new System.Drawing.Point(-5, -1);
            this.TopShapka.Name = "TopShapka";
            this.TopShapka.Size = new System.Drawing.Size(1592, 157);
            this.TopShapka.TabIndex = 70;
            // 
            // Vyiti
            // 
            this.Vyiti.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Vyiti.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Vyiti.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Vyiti.ForeColor = System.Drawing.Color.Yellow;
            this.Vyiti.Location = new System.Drawing.Point(160, 650);
            this.Vyiti.Name = "Vyiti";
            this.Vyiti.Size = new System.Drawing.Size(362, 74);
            this.Vyiti.TabIndex = 73;
            this.Vyiti.Text = "Выйти";
            this.Vyiti.UseVisualStyleBackColor = false;
            this.Vyiti.Click += new System.EventHandler(this.Vyiti_Click);
            // 
            // Titulnaya
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(1582, 753);
            this.Controls.Add(this.Avtorizaciya);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.text2);
            this.Controls.Add(this.text1);
            this.Controls.Add(this.TopShapka);
            this.Controls.Add(this.Vyiti);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Titulnaya";
            this.Text = "Евро-Сервис";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button Avtorizaciya;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label text2;
        private System.Windows.Forms.Label text1;
        private System.Windows.Forms.Label TopShapka;
        private System.Windows.Forms.Button Vyiti;
    }
}

